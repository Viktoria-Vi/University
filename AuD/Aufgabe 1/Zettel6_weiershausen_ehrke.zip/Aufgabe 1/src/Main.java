public class Main extends QuickSort{
    public static void whyAreYouRunning() {
        int[] a = createSequenceInc(100),
                b = createSequenceInc(1000),
                c = createSequenceInc(10000);
        int[] d = createSequenceInc(100000);
        int[] e = createSequenceInc(200000);
        long averageA = 0,
                averageB = 0,
                averageC = 0,
                averageD = 0,
                averageE = 0;

        for (int z = 0; z == 0; z++) { //lul

            for (int i = 0; i < 10; i++) {

                long startA = System.nanoTime();
                quickSort(a, 0, a.length - 1);
                long endA = System.nanoTime();
                averageA += endA - startA;

                long startB = System.nanoTime();
                quickSort(b, 0, b.length - 1);
                long endB = System.nanoTime();
                averageB += endB - startB;

                long startC = System.nanoTime();
                quickSort(c, 0, c.length - 1);
                long endC = System.nanoTime();
                averageC += endC - startC;


/*
                long startD = System.nanoTime();
                quickSort(d, 0, d.length - 1);
                long endD = System.nanoTime();
                 averageD += endD - startD;
*/


/*
                long startE = System.nanoTime();
                quickSort(e, 0, e.length - 1);
                long endE = System.nanoTime();
                averageE += endE - startE;
*/
            }
            System.out.println("Gesamtlaufzeit quickSort(Inc) 100 = " + averageA + " ns");
            System.out.println("Gesamtlaufzeit quickSort(Inc) 1000 = " + averageB + " ns");
            System.out.println("Gesamtlaufzeit quickSort(Inc) 10000 = " + averageC + " ns");
            System.out.println("Gesamtlaufzeit quickSort(Inc) 100000 = " + averageD + " ns");
            System.out.println("Gesamtlaufzeit quickSort(Inc) 2000000 = " + averageE + " ns");

            a = createSequenceDec(100);
            b = createSequenceDec(1000);
            c = createSequenceDec(10000);
            d = createSequenceDec(100000);
            e = createSequenceDec(200000);
            averageA = 0;
            averageB = 0;
            averageC = 0;
            averageD = 0;
            averageE = 0;

            for (int i = 0; i < 10; i++) {

                long startA = System.nanoTime();
                quickSort(a, 0, a.length - 1);
                long endA = System.nanoTime();
                averageA += endA - startA;

                long startB = System.nanoTime();
                quickSort(b, 0, b.length - 1);
                long endB = System.nanoTime();
                averageB += endB - startB;

                long startC = System.nanoTime();
                quickSort(c, 0, c.length - 1);
                long endC = System.nanoTime();
                averageC += endC - startC;


/*
                long startD = System.nanoTime();
                quickSort(d, 0, d.length - 1);
                long endD = System.nanoTime();
                averageD += endD - startD;
*/


/*
                long startE = System.nanoTime();
                quickSort(e, 0, e.length - 1);
                long endE = System.nanoTime();
                averageE += endE - startE;
*/
            }

            System.out.println("Gesamtlaufzeit quickSort(Dec) 100 = " + averageA + " ns");
            System.out.println("Gesamtlaufzeit quickSort(Dec) 1000 = " + averageB + " ns");
            System.out.println("Gesamtlaufzeit quickSort(Dec) 10000 = " + averageC + " ns");
            System.out.println("Gesamtlaufzeit quickSort(Dec) 100000 = " + averageD + " ns");
            System.out.println("Gesamtlaufzeit quickSort(Dec) 2000000 = " + averageE + " ns");
            a = createSequenceRand(100);
            b = createSequenceRand(1000);
            c = createSequenceRand(10000);
            d = createSequenceRand(100000);
            e = createSequenceRand(200000);
            averageA = 0;
            averageB = 0;
            averageC = 0;
            averageD = 0;
            averageE = 0;

            for (int i = 0; i < 10; i++) {

                long startA = System.nanoTime();
                quickSort(a, 0, a.length - 1);
                long endA = System.nanoTime();
                averageA += endA - startA;

                long startB = System.nanoTime();
                quickSort(b, 0, b.length - 1);
                long endB = System.nanoTime();
                averageB += endB - startB;

                long startC = System.nanoTime();
                quickSort(c, 0, c.length - 1);
                long endC = System.nanoTime();
                averageC += endC - startC;


/*
                long startD = System.nanoTime();
                quickSort(d, 0, d.length - 1);
                long endD = System.nanoTime();
                averageD += endD - startD;
*/


/*
                long startE = System.nanoTime();
                quickSort(e, 0, e.length - 1);
                long endE = System.nanoTime();
                averageE += endE - startE;
*/
            }
            System.out.println("Gesamtlaufzeit quickSort(Rand) 100 = " + averageA + " ns");
            System.out.println("Gesamtlaufzeit quickSort(Rand) 1000 = " + averageB + " ns");
            System.out.println("Gesamtlaufzeit quickSort(Rand) 10000 = " + averageC + " ns");
            System.out.println("Gesamtlaufzeit quickSort(Rand) 100000 = " + averageD + " ns");
            System.out.println("Gesamtlaufzeit quickSort(Rand) 2000000 = " + averageE + " ns");

            a = createSequenceInc(100);
            b = createSequenceInc(1000);
            c = createSequenceInc(10000);
            d = createSequenceInc(100000);
            e = createSequenceInc(200000);
            averageA = 0;
            averageB = 0;
            averageC = 0;
            averageD = 0;
            averageE = 0;

            for (int i = 0; i < 10; i++) {

                long startA = System.nanoTime();
                quickSortRand(a, 0, a.length - 1);
                long endA = System.nanoTime();
                averageA += endA - startA;

                long startB = System.nanoTime();
                quickSortRand(b, 0, b.length - 1);
                long endB = System.nanoTime();
                averageB += endB - startB;

                long startC = System.nanoTime();
                quickSortRand(c, 0, c.length - 1);
                long endC = System.nanoTime();
                averageC += endC - startC;


                long startD = System.nanoTime();
                quickSortRand(d, 0, d.length - 1);
                long endD = System.nanoTime();
                averageD += endD - startD;


                long startE = System.nanoTime();
                quickSortRand(e, 0, e.length - 1);
                long endE = System.nanoTime();
                averageE += endE - startE;
            }
            System.out.println("Gesamtlaufzeit quickSortRand(Inc) 100 = " + averageA + " ns");
            System.out.println("Gesamtlaufzeit quickSortRand(Inc) 1000 = " + averageB + " ns");
            System.out.println("Gesamtlaufzeit quickSortRand(Inc) 10000 = " + averageC + " ns");
            System.out.println("Gesamtlaufzeit quickSortRand(Inc) 100000 = " + averageD + " ns");
            System.out.println("Gesamtlaufzeit quickSortRand(Inc) 2000000 = " + averageE + " ns");
            a = createSequenceDec(100);
            b = createSequenceDec(1000);
            c = createSequenceDec(10000);
            d = createSequenceDec(100000);
            e = createSequenceDec(200000);
            averageA = 0;
            averageB = 0;
            averageC = 0;
            averageD = 0;
            averageE = 0;

            for (int i = 0; i < 10; i++) {

                long startA = System.nanoTime();
                quickSortRand(a, 0, a.length - 1);
                long endA = System.nanoTime();
                averageA += endA - startA;

                long startB = System.nanoTime();
                quickSortRand(b, 0, b.length - 1);
                long endB = System.nanoTime();
                averageB += endB - startB;

                long startC = System.nanoTime();
                quickSortRand(c, 0, c.length - 1);
                long endC = System.nanoTime();
                averageC += endC - startC;


                long startD = System.nanoTime();
                quickSortRand(d, 0, d.length - 1);
                long endD = System.nanoTime();
                averageD += endD - startD;


                long startE = System.nanoTime();
                quickSortRand(e, 0, e.length - 1);
                long endE = System.nanoTime();
                averageE += endE - startE;
            }
            System.out.println("Gesamtlaufzeit quickSortRand(Dec) 100 = " + averageA + " ns");
            System.out.println("Gesamtlaufzeit quickSortRand(Dec) 1000 = " + averageB + " ns");
            System.out.println("Gesamtlaufzeit quickSortRand(Dec) 10000 = " + averageC + " ns");
            System.out.println("Gesamtlaufzeit quickSortRand(Dec) 100000 = " + averageD + " ns");
            System.out.println("Gesamtlaufzeit quickSortRand(Dec) 2000000 = " + averageE + " ns");
            a = createSequenceRand(100);
            b = createSequenceRand(1000);
            c = createSequenceRand(10000);
            d = createSequenceRand(100000);
            e = createSequenceRand(200000);
            averageA = 0;
            averageB = 0;
            averageC = 0;
            averageD = 0;
            averageE = 0;

            for (int i = 0; i < 10; i++) {

                long startA = System.nanoTime();
                quickSortRand(a, 0, a.length - 1);
                long endA = System.nanoTime();
                averageA += endA - startA;

                long startB = System.nanoTime();
                quickSortRand(b, 0, b.length - 1);
                long endB = System.nanoTime();
                averageB += endB - startB;

                long startC = System.nanoTime();
                quickSortRand(c, 0, c.length - 1);
                long endC = System.nanoTime();
                averageC += endC - startC;


                long startD = System.nanoTime();
                quickSortRand(d, 0, d.length - 1);
                long endD = System.nanoTime();
                averageD += endD - startD;


                long startE = System.nanoTime();
                quickSortRand(e, 0, e.length - 1);
                long endE = System.nanoTime();
                averageE += endE - startE;
            }
            System.out.println("Gesamtlaufzeit quickSortRand(Rand) 100 = " + averageA + " ns");
            System.out.println("Gesamtlaufzeit quickSortRand(Rand) 1000 = " + averageB + " ns");
            System.out.println("Gesamtlaufzeit quickSortRand(Rand) 10000 = " + averageC + " ns");
            System.out.println("Gesamtlaufzeit quickSortRand(Rand) 100000 = " + averageD + " ns");
            System.out.println("Gesamtlaufzeit quickSortRand(Rand) 2000000 = " + averageE + " ns");

            a = createSequenceInc(100);
            b = createSequenceInc(1000);
            c = createSequenceInc(10000);
            d = createSequenceInc(100000);
            e = createSequenceInc(200000);
            averageA = 0;
            averageB = 0;
            averageC = 0;
            averageD = 0;
            averageE = 0;

            for (int i = 0; i < 10; i++) {

                long startA = System.nanoTime();
                quickSortNewRand(a, 0, a.length - 1);
                long endA = System.nanoTime();
                averageA += endA - startA;

                long startB = System.nanoTime();
                quickSortNewRand(b, 0, b.length - 1);
                long endB = System.nanoTime();
                averageB += endB - startB;

                long startC = System.nanoTime();
                quickSortNewRand(c, 0, c.length - 1);
                long endC = System.nanoTime();
                averageC += endC - startC;


                long startD = System.nanoTime();
                quickSortNewRand(d, 0, d.length - 1);
                long endD = System.nanoTime();
                averageD += endD - startD;


                long startE = System.nanoTime();
                quickSortNewRand(e, 0, e.length - 1);
                long endE = System.nanoTime();
                averageE += endE - startE;
            }
            System.out.println("Gesamtlaufzeit quickSortNewRand(Inc) 100 = " + averageA + " ns");
            System.out.println("Gesamtlaufzeit quickSortNewRand(Inc) 1000 = " + averageB + " ns");
            System.out.println("Gesamtlaufzeit quickSortNewRand(Inc) 10000 = " + averageC + " ns");
            System.out.println("Gesamtlaufzeit quickSortNewRand(Inc) 100000 = " + averageD + " ns");
            System.out.println("Gesamtlaufzeit quickSortNewRand(Inc) 2000000 = " + averageE + " ns");

            a = createSequenceDec(100);
            b = createSequenceDec(1000);
            c = createSequenceDec(10000);
            d = createSequenceDec(100000);
            e = createSequenceDec(200000);
            averageA = 0;
            averageB = 0;
            averageC = 0;
            averageD = 0;
            averageE = 0;

            for (int i = 0; i < 10; i++) {

                long startA = System.nanoTime();
                quickSortNewRand(a, 0, a.length - 1);
                long endA = System.nanoTime();
                averageA += endA - startA;

                long startB = System.nanoTime();
                quickSortNewRand(b, 0, b.length - 1);
                long endB = System.nanoTime();
                averageB += endB - startB;

                long startC = System.nanoTime();
                quickSortNewRand(c, 0, c.length - 1);
                long endC = System.nanoTime();
                averageC += endC - startC;


                long startD = System.nanoTime();
                quickSortNewRand(d, 0, d.length - 1);
                long endD = System.nanoTime();
                averageD += endD - startD;


                long startE = System.nanoTime();
                quickSortNewRand(e, 0, e.length - 1);
                long endE = System.nanoTime();
                averageE += endE - startE;
            }
            System.out.println("Gesamtlaufzeit quickSortNewRand(Dec) 100 = " + averageA + " ns");
            System.out.println("Gesamtlaufzeit quickSortNewRand(Dec) 1000 = " + averageB + " ns");
            System.out.println("Gesamtlaufzeit quickSortNewRand(Dec) 10000 = " + averageC + " ns");
            System.out.println("Gesamtlaufzeit quickSortNewRand(Dec) 100000 = " + averageD + " ns");
            System.out.println("Gesamtlaufzeit quickSortNewRand(Dec) 2000000 = " + averageE + " ns");

            a = createSequenceRand(100);
            b = createSequenceRand(1000);
            c = createSequenceRand(10000);
            d = createSequenceRand(100000);
            e = createSequenceRand(200000);
            averageA = 0;
            averageB = 0;
            averageC = 0;
            averageD = 0;
            averageE = 0;
            for (int i = 0; i < 10; i++) {

                long startA = System.nanoTime();
                quickSortNewRand(a, 0, a.length - 1);
                long endA = System.nanoTime();
                averageA += endA - startA;

                long startB = System.nanoTime();
                quickSortNewRand(b, 0, b.length - 1);
                long endB = System.nanoTime();
                averageB += endB - startB;

                long startC = System.nanoTime();
                quickSortNewRand(c, 0, c.length - 1);
                long endC = System.nanoTime();
                averageC += endC - startC;


                long startD = System.nanoTime();
                quickSortNewRand(d, 0, d.length - 1);
                long endD = System.nanoTime();
                averageD += endD - startD;


                long startE = System.nanoTime();
                quickSortNewRand(e, 0, e.length - 1);
                long endE = System.nanoTime();
                averageE += endE - startE;
            }
            System.out.println("Gesamtlaufzeit quickSortNewRand(Rand) 100 = " + averageA + " ns");
            System.out.println("Gesamtlaufzeit quickSortNewRand(Rand) 1000 = " + averageB + " ns");
            System.out.println("Gesamtlaufzeit quickSortNewRand(Rand) 10000 = " + averageC + " ns");
            System.out.println("Gesamtlaufzeit quickSortNewRand(Rand) 100000 = " + averageD + " ns");
            System.out.println("Gesamtlaufzeit quickSortNewRand(Rand) 2000000 = " + averageE + " ns");
        }
    }

    public static void main(String[] args) {

        whyAreYouRunning();

    }
    /* Tri und NewTri laufen leider nicht

Gesamtlaufzeit quickSort(Inc) 100 = 280400 ns
Gesamtlaufzeit quickSort(Inc) 1000 = 6204600 ns
Gesamtlaufzeit quickSort(Inc) 10000 = 305802200 ns
Gesamtlaufzeit quickSort(Inc) 100000 = Exception
Gesamtlaufzeit quickSort(Inc) 2000000 = Exception
Gesamtlaufzeit quickSort(Dec) 100 = 358100 ns
Gesamtlaufzeit quickSort(Dec) 1000 = 6504700 ns
Gesamtlaufzeit quickSort(Dec) 10000 = 351793600 ns
Gesamtlaufzeit quickSort(Dec) 100000 = Exception
Gesamtlaufzeit quickSort(Dec) 2000000 = Exception
Gesamtlaufzeit quickSort(Rand) 100 = 103200 ns
Gesamtlaufzeit quickSort(Rand) 1000 = 2797100 ns
Gesamtlaufzeit quickSort(Rand) 10000 = 264657800 ns
Gesamtlaufzeit quickSort(Rand) 100000 = Exception
Gesamtlaufzeit quickSort(Rand) 2000000 = Exception
Gesamtlaufzeit quickSortRand(Inc) 100 = 310100 ns
Gesamtlaufzeit quickSortRand(Inc) 1000 = 2238200 ns
Gesamtlaufzeit quickSortRand(Inc) 10000 = 17120300 ns
Gesamtlaufzeit quickSortRand(Inc) 100000 = 148075100 ns
Gesamtlaufzeit quickSortRand(Inc) 2000000 = 293420600 ns
Gesamtlaufzeit quickSortRand(Dec) 100 = 151300 ns
Gesamtlaufzeit quickSortRand(Dec) 1000 = 1260400 ns
Gesamtlaufzeit quickSortRand(Dec) 10000 = 12943200 ns
Gesamtlaufzeit quickSortRand(Dec) 100000 = 132461700 ns
Gesamtlaufzeit quickSortRand(Dec) 2000000 = 272378000 ns
Gesamtlaufzeit quickSortRand(Rand) 100 = 160000 ns
Gesamtlaufzeit quickSortRand(Rand) 1000 = 1316000 ns
Gesamtlaufzeit quickSortRand(Rand) 10000 = 15834400 ns
Gesamtlaufzeit quickSortRand(Rand) 100000 = 147319100 ns
Gesamtlaufzeit quickSortRand(Rand) 2000000 = 290260500 ns
Gesamtlaufzeit quickSortNewRand(Inc) 100 = 298300 ns
Gesamtlaufzeit quickSortNewRand(Inc) 1000 = 1984300 ns
Gesamtlaufzeit quickSortNewRand(Inc) 10000 = 16682100 ns
Gesamtlaufzeit quickSortNewRand(Inc) 100000 = 172574200 ns
Gesamtlaufzeit quickSortNewRand(Inc) 2000000 = 360766600 ns
Gesamtlaufzeit quickSortNewRand(Dec) 100 = 213200 ns
Gesamtlaufzeit quickSortNewRand(Dec) 1000 = 1905900 ns
Gesamtlaufzeit quickSortNewRand(Dec) 10000 = 19948000 ns
Gesamtlaufzeit quickSortNewRand(Dec) 100000 = 198834400 ns
Gesamtlaufzeit quickSortNewRand(Dec) 2000000 = 396096800 ns
Gesamtlaufzeit quickSortNewRand(Rand) 100 = 240900 ns
Gesamtlaufzeit quickSortNewRand(Rand) 1000 = 2222600 ns
Gesamtlaufzeit quickSortNewRand(Rand) 10000 = 23574500 ns
Gesamtlaufzeit quickSortNewRand(Rand) 100000 = 245541700 ns
Gesamtlaufzeit quickSortNewRand(Rand) 2000000 = 514757900 ns*/
}
