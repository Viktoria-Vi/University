public class PeaDragonLeviathan extends Leviathan {

    public PeaDragonLeviathan(int size) throws WrongSizeException {
        if (size >= 110 * 100 && size <= 116 * 100) {
            this.sizeCm = size;
        } else {
            throw new WrongSizeException(size);
        }
    }
}
