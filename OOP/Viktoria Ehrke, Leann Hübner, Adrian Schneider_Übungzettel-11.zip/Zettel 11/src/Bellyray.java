public class Bellyray extends Herbivore {

    public Bellyray(int size) throws WrongSizeException {
        if (size >= 7 * 100 && size <= 9 * 100) {
            this.sizeCm = size;
        } else {
            throw new WrongSizeException(size);
        }
    }
}
