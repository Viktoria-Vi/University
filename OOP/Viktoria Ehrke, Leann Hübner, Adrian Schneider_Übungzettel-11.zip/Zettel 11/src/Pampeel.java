public class Pampeel extends Carnivore {

    public Pampeel(int size) throws WrongSizeException {
        if (size >= 20 * 100 && size <= 22 * 100) {
            this.sizeCm = size;
        } else {
            throw new WrongSizeException(size);
        }
    }
}
