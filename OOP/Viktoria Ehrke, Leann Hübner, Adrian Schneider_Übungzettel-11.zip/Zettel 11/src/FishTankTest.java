import java.util.ArrayList;
import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.*;

class FishTankTest {

    @org.junit.jupiter.api.Test
    void FishTankTestCase() throws Exception {
        FishTank test = new FishTank();
        Huddlefish Akito = new Huddlefish(80);
        Huddlefish Anna = new Huddlefish(90);
        Bellyray Mimi = new Bellyray(700);
        Bellyray Felix = new Bellyray(900);
        Quidshark Mankel = new Quidshark(1100);
        Quidshark Adi = new Quidshark(1200);
        Huddlefish Leann = new Huddlefish(81);
        Huddlefish Viktoria = new Huddlefish(82);
        Pampeel Daddy = new Pampeel(2069);
        Pampeel Mommy = new Pampeel(2169);
        KeeperLeviathan angryViktoria = new KeeperLeviathan(5400);
        PeaDragonLeviathan angryLeann = new PeaDragonLeviathan(11600);
        assertThrows(WrongSizeException.class, () -> new Huddlefish(69696969));
        assertThrows(WrongSizeException.class, () -> new PeaDragonLeviathan(1));
        SeaCreature[] testList = new SeaCreature[]{Akito, Anna, Mimi, Felix, Mankel, Adi, Leann, Viktoria, Daddy, Mommy};
        test.addCreature(Akito);
        test.addCreature(Anna);
        test.addCreature(Mimi);
        test.addCreature(Felix);
        test.addCreature(Mankel);
        test.addCreature(Adi);
        test.addCreature(Leann);
        test.addCreature(Viktoria);
        test.addCreature(Daddy);
        test.addCreature(Mommy);
        assertThrows(CreatureNotCompatibleException.class, () -> test.addCreature(angryViktoria));
        assertThrows(CreatureNotCompatibleException.class, () -> test.addCreature(angryLeann));
        assertEquals(test.getCreatures(), Arrays.asList(testList));
        SeaCreature[] filterTest1 = new SeaCreature[]{Akito, Anna, Mimi, Felix, Leann, Viktoria};
        assertEquals(test.filter(Leann), Arrays.asList(filterTest1));
        SeaCreature[] filterTest2 = new SeaCreature[]{Mankel, Adi, Daddy, Mommy};
        assertEquals(test.filter(Mankel), Arrays.asList(filterTest2));
        assertEquals(test.filter(angryLeann), new ArrayList<>());
    }
}