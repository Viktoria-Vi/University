public class WrongSizeException extends Exception {

    public WrongSizeException(int size) {
        super(size + " centimeters is not an allowed size for this creature");
    }
}
