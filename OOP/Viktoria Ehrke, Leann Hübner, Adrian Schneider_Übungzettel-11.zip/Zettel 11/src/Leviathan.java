public abstract class Leviathan extends SeaCreature{
}
