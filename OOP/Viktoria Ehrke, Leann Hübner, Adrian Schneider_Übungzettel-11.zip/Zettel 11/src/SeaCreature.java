abstract class SeaCreature {
    protected int sizeCm;

//Hallo mein Schatz, wäre das so auch richtig? Mich verwirrt das static hier <3
    /*abstract static class Herbivore extends SeaCreature {
    }

    abstract static class Carnivore extends SeaCreature {
    }

    abstract static class Leviathan extends SeaCreature {
    }*/

}
