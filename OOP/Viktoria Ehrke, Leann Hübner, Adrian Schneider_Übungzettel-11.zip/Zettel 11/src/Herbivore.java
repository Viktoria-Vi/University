public abstract class Herbivore extends SeaCreature {
}
