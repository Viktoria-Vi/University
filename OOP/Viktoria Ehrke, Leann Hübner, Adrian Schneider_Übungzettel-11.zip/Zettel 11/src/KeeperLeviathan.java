public class KeeperLeviathan extends Leviathan {

    public KeeperLeviathan(int size) throws WrongSizeException {
        if (size >= 54 * 100 && size <= 56 * 100) {
            this.sizeCm = size;
        } else {
            throw new WrongSizeException(size);
        }
    }
}
