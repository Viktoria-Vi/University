public class CreatureNotCompatibleException extends Exception {

    public CreatureNotCompatibleException(SeaCreature creature) {
        super(creature + "not compatible in this fish tank");
    }
}
