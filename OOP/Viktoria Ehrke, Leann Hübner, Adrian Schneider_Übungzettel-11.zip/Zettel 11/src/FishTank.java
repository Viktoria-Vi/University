import java.util.ArrayList;
import java.util.List;

public class FishTank {
    private final ArrayList<SeaCreature> creatures;

    public FishTank() {
        this.creatures = new ArrayList<>();
    }

    public ArrayList<SeaCreature> getCreatures() {
        return creatures;
    }

    void addCreature(SeaCreature creature) throws CreatureNotCompatibleException {
        if (creature instanceof Leviathan) {
            throw new CreatureNotCompatibleException(creature);
        }
        creatures.add(creature);
    }

    public <T extends SeaCreature> List<T> filter(T creature) {
        List<T> filteredTank = new ArrayList<>();
        for (SeaCreature seaCreature : creatures) {
            if (creature.getClass().getSuperclass().isInstance(seaCreature)) {//je nach den was gefordert ist mit/ohne getSuperclass
                filteredTank.add((T) seaCreature);
            }
        }
        return filteredTank;
    }

}

