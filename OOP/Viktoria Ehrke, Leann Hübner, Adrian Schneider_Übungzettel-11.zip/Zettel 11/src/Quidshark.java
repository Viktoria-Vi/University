public class Quidshark extends Carnivore {

    public Quidshark(int size) throws WrongSizeException {
        if (size >= 11 * 100 && size <= 12 * 100) {
            this.sizeCm = size;
        } else {
            throw new WrongSizeException(size);
        }
    }
}
