public abstract class Carnivore extends SeaCreature {
}
