public class Huddlefish extends Herbivore {

    public Huddlefish(int size) throws WrongSizeException {
        if (size >= 0.8 * 100 && size <= 0.9 * 100) {
            this.sizeCm = size;
        } else {
            throw new WrongSizeException(size);
        }
    }
}
