import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

class NFATest {
    Alphabet alphabet = new Alphabet(new Character[]{'D', 'A', 'N', 'K', 'E', 'Y', 'H', 'U', 'S', 'O', 'C', 'B'});
    NFA test = new NFA(alphabet);
    State A01 = new State("01", false);
    State A02 = new State("02", false);
    State A03 = new State("03", false);
    State A04 = new State("04", false);
    State A05 = new State("05", true);
    State A06 = new State("06", false);
    State A07 = new State("07", false);
    State A08 = new State("08", false);
    State A09 = new State("09", true);

    @BeforeEach
    void setUp() throws Exception {

        test.addState(A01, true);
        test.addState(A02, false);
        test.addState(A03, false);
        test.addState(A04, false);
        test.addState(A05, false);
        test.addState(A06, false);
        test.addState(A07, false);
        test.addState(A08, false);
        test.addState(A09, false);
        test.addTransition(new Transition("01", "02", 'D'));
        test.addTransition(new Transition("02", "03", 'A'));
        test.addTransition(new Transition("03", "03", 'N'));
        test.addTransition(new Transition("03", "04", 'N'));
        test.addTransition(new Transition("03", "03", 'K'));
        test.addTransition(new Transition("04", "04", 'K'));
        test.addTransition(new Transition("03", "04", 'E'));
        test.addTransition(new Transition("04", "04", 'E'));
        test.addTransition(new Transition("04", "06", 'E'));
        test.addTransition(new Transition("04", "05", 'D'));
        test.addTransition(new Transition("05", "05", 'A'));
        test.addTransition(new Transition("05", "05", 'Y'));
        test.addTransition(new Transition("05", "04", 'D'));
        test.addTransition(new Transition("04", "06", 'D'));
        test.addTransition(new Transition("06", "05", 'A'));
        test.addTransition(new Transition("01", "02", 'H'));
        test.addTransition(new Transition("02", "07", 'U'));
        test.addTransition(new Transition("02", "08", 'U'));
        test.addTransition(new Transition("07", "09", 'S'));
        test.addTransition(new Transition("08", "09", 'S'));
        test.addTransition(new Transition("09", "09", 'O'));


    }

    @Test
    void addState() {
        assertThrows(StateAlreadyExistsException.class, () -> {
            test.addState(new State("04", false), false);
        });
    }

    @Test
    void findState() {
        assertEquals(test.findState("01"), A01);
        assertNull(test.findState("10"));
    }

    @Test
    void addTransition() throws Exception {
        assertThrows(TransitionAlreadyExistsException.class, () -> {
            test.addTransition(new Transition("02", "03", 'A'));
        });
        assertThrows(StateDoesNotExistException.class, () -> {
            test.addTransition(new Transition("10", "05", 'E'));
        });
        assertThrows(SymbolNotInAlphabetException.class, () -> {
            test.addTransition(new Transition("01", "04", 'a'));
        });
    }

    @Test
    void delta() throws SymbolNotInAlphabetException {
        ArrayList<State> testList = new ArrayList<>();
        test.reset();
        test.delta('D');
        assertAll(() -> {
            testList.clear();
            testList.add(A02);
            assertEquals(testList, test.currentStates);
        });
        test.delta('A');
        assertAll(() -> {
            testList.clear();
            testList.add(A03);
            assertEquals(testList, test.currentStates);
        });
        test.delta('N');
        assertAll(() -> {
            testList.clear();
            testList.add(A03);
            testList.add(A04);
            assertEquals(testList, test.currentStates);
        });
        test.delta('K');
        assertAll(() -> {
            testList.clear();
            testList.add(A03);
            testList.add(A04);
            assertEquals(testList, test.currentStates);
        });
        test.delta('E');
        assertAll(() -> {
            testList.clear();
            testList.add(A04);
            testList.add(A06);
            assertEquals(testList, test.currentStates);
        });
        test.delta('D');
        assertAll(() -> {
            testList.clear();
            testList.add(A05);
            testList.add(A06);
            assertEquals(testList, test.currentStates);
        });
        test.delta('A');
        assertAll(() -> {
            testList.clear();
            testList.add(A05);
            assertEquals(testList, test.currentStates);
        });
        test.delta('D');
        assertAll(() -> {
            testList.clear();
            testList.add(A04);
            assertEquals(testList, test.currentStates);
        });
        test.delta('D');
        assertAll(() -> {
            testList.clear();
            testList.add(A05);
            testList.add(A06);
            assertEquals(testList, test.currentStates);
        });
        test.delta('Y');
        assertAll(() -> {
            testList.clear();
            testList.add(A05);
            assertEquals(testList, test.currentStates);
        });
        assertTrue(test.isAccepting());
        //ich könnte hier noch den NFA mit dem Wort "HUSO" testen, aber tbh hab ich kein bock mehr.
    }
}