import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.Set;

public class NFA extends GenericAutomaton {
    protected ArrayList<State> currentStates = new ArrayList<>();

    public NFA(Alphabet alphabet) {
        super(alphabet);
        currentStates.add(findState(start));
    }

    @Override
    void reset() {
        currentStates.clear(); //löscht alles, setzt die liste aber auch null
        currentStates = new ArrayList<>(); //deswegen neu initialisieren
        currentStates.add(findState(start));

    }

    @Override
    boolean isAccepting() {
        for (State state : currentStates) {
            for (State inState : states) {
                if (state.equals(inState)) {
                    return true;
                }
            }
        }
        return false;
    }

    @Override
    public void addTransition(Transition transition) throws Exception {
        for (Transition transitionTest : transitions) {
            if (transitionTest.getSTART().equals(transition.getSTART()) && transitionTest.getEND().equals(transition.getEND()) && transitionTest.getSymbol().equals(transition.getSymbol())) {
                throw new TransitionAlreadyExistsException(transition); //keine komplett Identischen Transitions möglich
            }
        }
        super.addTransition(transition);
    }

    public ArrayList<State> delta(Character symbol) throws SymbolNotInAlphabetException { //Es wäre hier doch vielleicht schöner mit den einzelnen IDs(weil wir es ja sonst überall machen) zu arbeiten, aber naja Steffen unso
        if (!alphabet.doesContain(symbol)) {
            throw new SymbolNotInAlphabetException(symbol);
        }
        ArrayList<State> out = new ArrayList<>();
        for (State current : currentStates) {
            for (Transition transition : transitions) {
                if (current.getID().equals(transition.getSTART()) && transition.getSymbol().equals(symbol)) {
                    out.add(findState(transition.getEND()));
                }
            }
        }
        Set<State> set = new LinkedHashSet<>(out);//entfernt duplikate
        currentStates = new ArrayList<>(set);
        return out;
    }
}

