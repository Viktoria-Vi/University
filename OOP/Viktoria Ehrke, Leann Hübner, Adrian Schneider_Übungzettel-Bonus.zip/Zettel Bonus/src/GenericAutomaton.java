public abstract class GenericAutomaton {
    protected State[] states;
    protected Transition[] transitions;
    protected final Alphabet alphabet;
    protected String start;

    /**
     * Konstruktor, welcher ein Alphabet übergeben bekommt und alle anderen Felder mit Standartwerten initialisiert
     *
     * @param alphabet array an Symbolen
     */
    protected GenericAutomaton(Alphabet alphabet) {
        this.alphabet = alphabet;
        this.states = new State[0];
        this.transitions = new Transition[0];
        this.start = "";
    }

    abstract void reset();

    abstract boolean isAccepting();

    /**
     * Fügt dem states Array einen weiteren Zustand hinzu, sollte dieser noch nicht existieren
     *
     * @param state   übergebender Zustand welcher hinzugefügt werden soll
     * @param isStart falls true soll dies der start Zustand des automaten sein
     * @throws StateAlreadyExistsException wirft, wenn die ID des übergebenen State schon existiert
     */
    public void addState(State state, boolean isStart) throws StateAlreadyExistsException {
        if (findState(state.getID()) == null) {
            State[] addState = new State[states.length + 1];
            System.arraycopy(states, 0, addState, 0, states.length);
            addState[states.length] = state;
            this.states = addState;
            if (isStart) {
                start = state.getID();
            }
            return;
        }
        throw new StateAlreadyExistsException(state.getID());
    }

    /**
     * Gibt an, ob die übergebene ID schon in einem State vergeben ist
     *
     * @param ID zu überprüfende ID
     * @return gibt den State mit der ID zurück, oder null, falls es keinen passenden State gibt
     */
    public State findState(String ID) {
        for (State state : states) {
            if (state.getID().equals(ID)) {
                return state;
            }
        }
        return null;
    }

    /**
     * Fügt den transitions Array die übergebene Transition zu, falls die übergebenen Werte alle existieren
     *
     * @param transition hinzuzufügende Transition
     * @throws StateDoesNotExistException wirft, wenn entweder der start oder end Zustand nicht existieren
     * @throws SymbolNotInAlphabetException wirft, wenn das übergebene Symbol nicht existiert
     */
    protected void addTransition(Transition transition) throws Exception {
        boolean startStateContained = false;
        boolean endStateContained = false;
        boolean containsSymbol = alphabet.doesContain(transition.getSymbol());
        for (State state : states) {
            if (state.getID().equals(transition.getSTART())) {
                startStateContained = true;
            }
            if (state.getID().equals(transition.getEND())) {
                endStateContained = true;
            }
        }
        if (!startStateContained) {
            throw new StateDoesNotExistException(transition.getSTART());
        }
        if (!endStateContained) {
            throw new StateDoesNotExistException(transition.getEND());
        }
        if (!containsSymbol) {
            throw new SymbolNotInAlphabetException(transition.getSymbol());
        }
        Transition[] addTransition = new Transition[transitions.length + 1];
        System.arraycopy(transitions, 0, addTransition, 0, transitions.length);
        addTransition[transitions.length] = transition;
        transitions = addTransition;
    }
}