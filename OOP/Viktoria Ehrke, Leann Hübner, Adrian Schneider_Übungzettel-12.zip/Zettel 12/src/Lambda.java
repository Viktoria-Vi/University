import java.util.ArrayList;
import java.util.Comparator;
import java.util.function.Predicate;

public class Lambda {
    /**
     * Die methode entfernt alle Elemente aus List die auf das Prädikat filter zutreffen
     *
     * @param list   generische Liste
     * @param filter generisches Prädikat
     * @param <T>    generics YaY
     */
    public static <T> void removeIf(ArrayList<T> list, Predicate<T> filter) {
        list.removeIf(filter);
    }

    /**
     * Die Methode sortiert list nach dem gegebenen comparator
     *
     * @param list       generische Liste(again)
     * @param comparator generischer comparator
     * @param <T>        generics YAYAYAAYAYAYAYYAAYA
     */
    public static <T> void sortBy(ArrayList<T> list, Comparator<T> comparator) {
        list.sort(comparator);
    }

    /**
     * Die Methode wandelt list in einen String um und schreibt jedes Element in einen neue zeile
     *
     * @param list generische Liste(again again)
     * @param <T>  WTF schon wieder generics??!?!?!??! was da los !111!!11!11
     * @return gibt die Liste als String zurück
     */
    public static <T> String listToString(ArrayList<T> list) {
        StringBuilder out = new StringBuilder();
        list.forEach((x) -> {
            out.append(x).append("\n");
        });
        return out.toString();
    }
}
