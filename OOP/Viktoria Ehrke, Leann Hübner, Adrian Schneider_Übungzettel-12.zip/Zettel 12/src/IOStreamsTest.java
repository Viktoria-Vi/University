import org.junit.jupiter.api.Test;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class IOStreamsTest {

    @Test
    void writeCountedWords() throws IOException {
        File source = new File(Paths.get(".").toAbsolutePath().normalize() + "\\theRaven.txt");
        File test = new File(Paths.get(".").toAbsolutePath().normalize() + "\\countedWords.txt");
        File dest = new File(Paths.get(".").toAbsolutePath().normalize() + "\\DankeDaddy.txt");
        assertTrue(source.exists());
        assertTrue(test.exists());
        assertTrue(dest.exists());
        IOStreams.writeCountedWords(IOStreams.countWords(IOStreams.words(source.toString())), dest.getPath());
        List<String> file1 = Files.readAllLines(Paths.get(test.getPath()));
        List<String> file2 = Files.readAllLines(Paths.get(dest.getPath()));
        assertEquals(file1.size(), file2.size());
        for (int i = 0; i < file1.size(); i++) { //Zeile für zeile Vergleich
            assertEquals(file1.get(i), file2.get(i));
        }
    }
}