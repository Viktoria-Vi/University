import java.io.*;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class IOStreams {

    public static Stream<String> words(String filePath) throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(filePath));
        List<String> replaced = new ArrayList<>();
        String line = reader.readLine();//wir gehen hier line by line durch um (bestimmte) Sonderzeichen gleich entfernen zu können.
        while (line != null) {
            replaced.add(line.replaceAll("[',—“;’!?.”‘-]", ""));//Steffens regex
            //replaced.add(line.replaceAll("'", ""));*/ //Mein regex(Die Bessere!), weil es dann alles echte Wörter sind
            line = reader.readLine();
        }
        reader.close();//be a good fellow and close the reader shawty
        return replaced.stream()
                .flatMap(str -> Arrays.stream(str.split("[ \n]")))//Was ist ein Wort? Alles nach einer Leerzeile oder einem Umbruch
                .filter(str -> str.length() > 0);
    }

    /**
     * Die Methode zählt die Worte in einer Map. für den fall das ein noch nicht bearbeiter Stream übergeben wird,
     * wird hier nochmal klargestellt was ein Wort(bzw ein Key ist) ist.
     * @param words der übergebene Stream von Wörtern/Text
     * @return gibt eine Map wieder, Key ist hier jeweils ein Wort und Value dessen vorkommen
     */
    public static Map<String, Integer> countWords(Stream<String> words) {
        return words.flatMap(str -> Arrays.stream(str.split("[ \n]")))
                .filter(str -> str.length() > 0)
                .collect(Collectors.toMap(Function.identity(), e -> 1, Integer::sum));
    }

    public static void writeCountedWords(Map<String, Integer> countedWords, String filepath) {
        try (BufferedWriter bf = new BufferedWriter(new FileWriter(filepath))) {
            for (Map.Entry<String, Integer> entry : countedWords.entrySet()) {
                bf.write(entry.getKey() + " : " + entry.getValue());
                bf.newLine();
            }
            bf.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        String destStr = Paths.get(".").toAbsolutePath().normalize().toString() + "\\a";


    }
}

