import java.util.ArrayList;
import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.*;

class LambdaTest {

    ArrayList<Integer> testList1 = new ArrayList<>();
    ArrayList<Integer> testList2 = new ArrayList<>();

    /**
     * Erstellt zwei Integer Listen(weil handlich lol)
     */
    @org.junit.jupiter.api.BeforeEach
    void setUp() {
        for (int i = 0; i < 10; i++) {
            testList1.add(i + i);
            testList2.add(i * 5);
        }
    }


    @org.junit.jupiter.api.Test
    void removeIf() {
        Lambda.removeIf(testList1, n -> n % 2 == 0);
        Integer[] testArr1 = new Integer[]{};//es wurden alle Elemente entfernt, da i + i immer %2== 0 erfüllt
        Lambda.removeIf(testList2, n -> n % 2 == 0);
        Integer[] testArr2 = new Integer[]{5, 15, 25, 35, 45};//alle geraden Elemente wurden entfernt(10,20,...
        assertEquals(testList1, Arrays.asList(testArr1));
        assertEquals(testList2, Arrays.asList(testArr2));

    }

    @org.junit.jupiter.api.Test
    void sortBy() {
        testList1.add(-1);//add a little bit of spice
        testList2.add(-1);
        Lambda.sortBy(testList1, (n, f) -> n - f);
        Integer[] testArr1 = new Integer[]{-1, 0, 2, 4, 6, 8, 10, 12, 14, 16, 18};//von kleinsten zum größten sortiert
        Lambda.sortBy(testList2, (n, f) -> f - n);
        Integer[] testArr2 = new Integer[]{45, 40, 35, 30, 25, 20, 15, 10, 5, 0, -1};//^ vice versa
        assertEquals(testList1, Arrays.asList(testArr1));
        assertEquals(testList2, Arrays.asList(testArr2));
    }

    @org.junit.jupiter.api.Test
    void listToString() {
        assertEquals(Lambda.listToString(testList1), "0\n2\n4\n6\n8\n10\n12\n14\n16\n18\n"); //joa is halt nen string ne.
        assertEquals(Lambda.listToString(testList2), "0\n5\n10\n15\n20\n25\n30\n35\n40\n45\n");//da btw auch
    }
}