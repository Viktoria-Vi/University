import java.util.Arrays;

public class GoodsSegment {
    public double height;
    public double width;
    public double depth;
    public double maxWeight;
    public GoodsCrate[] subSegments;

    public GoodsSegment(double height, double width, double depth, double maxWeight) {
        this.height = height;
        this.width = width;
        this.depth = depth;
        this.maxWeight = maxWeight;
        subSegments = new GoodsCrate[9];
    }

    /**
     * Die Methode geht alle stellen von segments durch und addiert diese in der Var registeredWeight auf.
     * Am Ende wird überprüft, ob das Einlagern von crate das Maximalgewicht überschreiten würde.
     *
     * @param crate ein Objekt der klasse GoodsCrate
     * @return gint an ob das maxWeight überschritten werden würde(false) beim Einlagern von crate oder nicht(true)
     */
    public boolean checkWeight(GoodsCrate crate) {
        double registeredWeight = 0;
        for (int i = 0; i < subSegments.length; i++) {
            if (subSegments[i] != null) {
                registeredWeight += subSegments[i].weight;
            }
        }
        if (registeredWeight + crate.weight > maxWeight) {
            return false;
        }
        return true;
    }

    /**
     * Die Methode checkSpace überprüft, ob sich noch ein freier Platz in segments befindet.
     *
     * @return gibt true zurück, wenn mindestens eine Stelle in segments mit null(dem Standardwert) befüllt ist.
     */

    public boolean checkSpace() {
        for (int i = 0; i < subSegments.length; i++) {
            if (subSegments[i] == null) {
                return true;
            }
        }
        return false;
    }

    /**
     * Die Methode getSortedDimensions erstellt einen double Array mit den Dimensionen von einer Box in segments.
     *
     * @return gibt den erstellten Array aus.
     */

    public double[] getSortedDimensions() {
        double[] dimensions = new double[]{height / 3, width / 3, depth / 3};
        Arrays.sort(dimensions);
        return dimensions;
    }

    /**
     * Die Methode checkDimensions überprüft, ob die sortierten Dimensionen der segment Box jeweils kleiner sind als die sortierten Dimensionen der crate.
     *
     * @param crate ein Objekt der klasse GoodsCrate.
     * @return gibt true aus wenn crate in das segment passt, false wenn nicht
     */

    public boolean checkDimensions(GoodsCrate crate) {
        double[] dimensions = new double[]{height / 3, width / 3, depth / 3};
        double[] crateDimensions = new double[]{crate.height, crate.width, crate.depth};
        Arrays.sort(dimensions);
        Arrays.sort(crateDimensions);
        if (dimensions[0] < crateDimensions[0] || dimensions[1] < crateDimensions[1] || dimensions[2] < crateDimensions[2]) {
            return false;
        }
        return true;
    }

    /**
     * Die Methode addCrate fügt crate dem segment zu, falls alle Bedingungen erfüllt sind
     *
     * @param crate ein Objekt der klasse GoodsCrate.
     */

    void addCrate(GoodsCrate crate) {
        if (!checkSpace()) {
            System.out.println("No free Subsegments found");
            return;
        }
        if (!checkWeight(crate)) {
            System.out.println("Crate cannot be stored, max weight limit would be exceeded");
            return;
        }
        if (!checkDimensions(crate)) {
            System.out.println("Crate will not fit in subsegment");
            return;
        }
        int freeSubSegment = -1;
        for (int i = 0; i < subSegments.length; i++) {
            if (subSegments[i] == null) {
                freeSubSegment = i;
                break;
            }
        }
        subSegments[freeSubSegment] = crate;
    }
}