public class Reverse {
    /**
     * Die Methode nimmt zwei beliebige Strings entgegen und vergleicht die einzelnen Char's miteinander,
     * wenn a und b unterschiedliche Längen haben, soll sofort false ausgegeben werden.
     * Die Groß- und Kleinschreibung der Strings soll egal sein
     */
    public static boolean isReverse(String a, String b) {
        if (a.length() == b.length()) {
            a = a.toUpperCase();
            b = b.toUpperCase();
            for (int i = 0; i < a.length(); i++) {
                if (a.charAt(i) != b.charAt(b.length() - i - 1)) { //b.length()-i-1 geht die Chars von hinten ab
                    return false;
                }
            }
            return true;
        }
        return false;
    }
}
