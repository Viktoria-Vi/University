public class GoodsShelfSystem {
    public GoodsSegment[] segments;

    /**
     * Dieser Konstruktor ist aus mir unerklärlichen gründen in der Aufgabe gefordert. See below für einen sinnvolleren Konstruktor
     */
    public GoodsShelfSystem() {
        this.segments = new GoodsSegment[]{new GoodsSegment(20, 42, 11, 100)
                , new GoodsSegment(99, 42, 45, 100)
                , new GoodsSegment(9, 9, 9, 25)
                , new GoodsSegment(24, 42, 44, 150)
                , new GoodsSegment(24, 42, 11, 100)};
    }

    /**
     * Woooow wie schön das man ein beliebig großes Array an segments eingeben kann und nicht auf die 5 beschränkt ist von
     * vornherein
     *
     * @param segments ein viel cooleres Array als hier drüber
     */
    public GoodsShelfSystem(GoodsSegment[] segments) {
        this.segments = segments;
    }

    /**
     * Die Methode beginnt damit einen 2Dimensionalen Array aus den Sortierten segments zu erstellen. Dann wird das erste passende segment gesucht und
     * als fittingSegment gespeichert. Falls ein passendes Segment gefunden wurde, wird in einer weiteren Schleife untersucht ob
     * ein anderes passendes segment kleiner ist.
     *
     * @param crate ein Objekt der Klasse GoodsCrate.
     * @return gibt false zurück, falls die crate nicht einsortiert werden konnte, und true falls ja.
     */
    public boolean findSegmentForCrate(GoodsCrate crate) {
        double[][] segmentsDimension = new double[segments.length][];
        for (int i = 0; i < segments.length; i++) {
            segmentsDimension[i] = segments[i].getSortedDimensions();
        }
        int fittingSegment = -1;
        for (int i = 0; i < segments.length; i++) {
            if (segments[i].checkWeight(crate) && segments[i].checkSpace() && segments[i].checkDimensions(crate)) {
                fittingSegment = i;
                break;
            }
        }
        if (fittingSegment != -1) {
            for (int newSegment = fittingSegment; newSegment < segments.length; newSegment++) {
                if (segments[newSegment].checkWeight(crate) && segments[newSegment].checkSpace() && segments[newSegment].checkDimensions(crate)) {
                    if (segmentsDimension[newSegment][0] <= segmentsDimension[fittingSegment][0] &&
                            segmentsDimension[newSegment][1] <= segmentsDimension[fittingSegment][1] &&
                            segmentsDimension[newSegment][2] <= segmentsDimension[fittingSegment][2]) {
                        fittingSegment = newSegment;
                    }
                }
            }
            segments[fittingSegment].addCrate(crate);
            System.out.println("Segment dimensions:" + "\n" + "height: " + segments[fittingSegment].height + "\n" + "width: "
                    + segments[fittingSegment].width + "\n" + "depth: " + segments[fittingSegment].depth);
            System.out.println("Crate added to Segment " + (fittingSegment + 1));
            return true;
        }
        System.out.println("No fitting segment found");
        return false;
    }

    //for your testing my love
    public static void main(String[] args) {
        GoodsCrate testCrate = new GoodsCrate(14, 14, 9, 5);
        GoodsShelfSystem testShelf = new GoodsShelfSystem(new GoodsSegment[]{new GoodsSegment(20, 42, 11, 100)
                , new GoodsSegment(99, 42, 45, 100)
                , new GoodsSegment(9, 9, 9, 25)
                , new GoodsSegment(24, 42, 44, 150)
                , new GoodsSegment(24, 42, 11, 100)});
        testShelf.findSegmentForCrate(testCrate);
    }
}
