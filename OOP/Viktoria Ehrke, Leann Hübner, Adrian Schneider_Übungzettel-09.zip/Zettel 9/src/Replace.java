public class Replace {
    /**
     * Die Methode nimmt einen String source entgegen, in welchen die char-Sequenz welche in String search
     * eingegeben wird gesucht wird und dann durch die Sequenz in String replace ersetzt wird.
     * Die while Schleife läuft so lange wie die Sequenz search im verbleibenden Wort gefunden wird,
     * wenn dies nicht der fall ist, gibt source.indexOf(search, i) - 1 aus und der Ergebnisstring
     * wird um den Rest des Wortes ergänzt und ausgegeben.
     *
     * @param source  gibt den quell-String an der in der Methode verändert werden soll
     * @param search  gibt die zu suchende Sequenz an
     * @param replace gibt die Sequenz an die für search eingesetzt werden soll
     * @return gibt den Ergebnisstring aus
     */

    public static String replace(String source, String search, String replace) {
        String resultString = "";
        int i = 0;
        while (source.indexOf(search, i) != -1) { //-1 ist das Ergebnis, wenn search nicht enthalten ist in source
            int j = source.indexOf(search, i);
            resultString += source.substring(i, j) + replace; //Aufbau des Ergebnisstrings mit allem vor der zu ersetzenden Sequenz und der Sequenz
            i += j + search.length(); //neuer Index von i wird die Stelle, an dem die gesuchte Sequenz angefangen hat plus der Länge des eingesetzten Strings
        }
        if (i < source.length()) { //fügt den Rest des Strings an. Wenn search nicht im string enthalten war, wird der ganze String kopiert
            resultString += source.substring(i);
        }
        return resultString;
    }
}
