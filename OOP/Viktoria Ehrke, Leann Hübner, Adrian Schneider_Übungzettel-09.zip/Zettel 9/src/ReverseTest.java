import static org.junit.jupiter.api.Assertions.*;

class ReverseTest {

    @org.junit.jupiter.api.Test
    void isReverse() {
        assertTrue(Reverse.isReverse("Danke Daddy", "yddaD eknaD")); //Damit ist Leann gemeint ;)
        assertTrue(Reverse.isReverse("lagerregal", "LAGERREGAL"));
        assertTrue(Reverse.isReverse("Keine Ahnung", "GnUnHa EnIeK"));
        assertTrue(Reverse.isReverse("Maus", "Suam"));
        assertTrue(Reverse.isReverse("HDGDL", "ldgdh"));
        assertFalse(Reverse.isReverse("Leerzeichen sind Wichtig", "githciWdnisnehciezreeL"));
        assertFalse(Reverse.isReverse("Das geht auch nicht", "lol"));
        assertFalse(Reverse.isReverse("CTRL-C", "CTRL-C"));
        assertFalse(Reverse.isReverse("Testing is", "Important"));
        assertFalse(Reverse.isReverse("nochmal Danke Daddy", "yyddaD eknaD lamhcon")); // damit auch
    }
}