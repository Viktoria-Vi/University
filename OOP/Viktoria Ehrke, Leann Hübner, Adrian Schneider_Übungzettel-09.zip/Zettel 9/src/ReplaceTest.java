import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ReplaceTest {

    @Test
    void replace() {
        assertEquals(Replace.replace("Danke Daddy", "y", "y Danke Daddy"), "Danke Daddy Danke Daddy"); //still not you Mankel :)
        assertEquals(Replace.replace("Lol", "l", "tr"), "Lotr");
        assertEquals(Replace.replace("bAAA", "AA", "a"), "baA");
        assertEquals(Replace.replace("Miau", "Wuff", "Piep"), "Miau");
        assertEquals(Replace.replace("test", "test", "test"), "test");
        assertNotEquals(Replace.replace("Hallo", "h", "h"), "hallo");//sondern Hallo
        assertNotEquals(Replace.replace("Mäus Mäus", "s", "se"), "Mäusemäuse");//Sondern Mause Mause
    }
}