public class GoodsCrate {
    public double height;
    public double width;
    public double depth;
    public double weight;

    public GoodsCrate(double height, double width, double depth, double weight) {
        this.height = height;
        this.width = width;
        this.depth = depth;
        this.weight = weight;
    }
}
