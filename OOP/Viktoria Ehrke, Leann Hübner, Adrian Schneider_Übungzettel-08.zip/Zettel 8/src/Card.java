public class Card implements Comparable {

    private final String NAME;
    private final int TYPE;
    public static final int EFFECT_MONSTER = 2; //Durch das erstellen einzelner Felder kann man nacher mit Card.usw darauf zugreifen (s. CardTest)
    public static final int NORMAL_MONSTER = 1;
    public static final int SPELL_CARD = 3;
    public static final int TRAP_CARD = 4;
    private final int RELEASE;

    public Card(String name, int type, int release) {
        this.NAME = name;
        this.RELEASE = release;
        if (type == EFFECT_MONSTER) {
            this.TYPE = EFFECT_MONSTER;
        } else if (type == NORMAL_MONSTER) {
            this.TYPE = NORMAL_MONSTER;
        } else if (type == SPELL_CARD) {
            this.TYPE = SPELL_CARD;
        } else if (type == TRAP_CARD) {
            this.TYPE = TRAP_CARD;
        } else {
            this.TYPE = TRAP_CARD; //unnessecary Statement lol
        }
    }

    public String getNAME() {
        return NAME;
    }

    public int getRELEASE() {
        return RELEASE;
    }

    public int getTYPE() {
        return TYPE;
    }

    @Override
    public String toString() { //Schreibt vor wie die toString methode funktioniert(war mal sinnvoll für mich, jetzt nimmer :/)
        if (TYPE == 1) {
            return "NORMAL_MONSTER: " + NAME;
        }
        if (TYPE == 2) {
            return "EFFECT_MONSTER: " + NAME;
        }
        if (TYPE == 3) {
            return "SPELL_CARD: " + NAME;
        } else {
            return "TRAP_CARD: " + NAME;
        }
    }

    @Override
    public int compareTo(Object o) {
        Card other = (Card) o; //Object wir in ein Card-Object umgewandelt(ge-castet)
        int result = Integer.compare(this.getRELEASE(), other.getRELEASE());
        if (result == 0) {
            result = Integer.compare(this.getTYPE(), other.getTYPE());
        }
        if (result == 0) {
            result = this.getNAME().compareTo(other.getNAME());
        }
        return result;
    }
}




