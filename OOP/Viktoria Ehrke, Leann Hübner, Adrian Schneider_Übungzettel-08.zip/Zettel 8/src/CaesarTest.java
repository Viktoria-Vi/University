import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CaesarTest {

    @Test
    void decode() {
        assertEquals(Caesar.decode("HGXBO", 'W', 'Z'), "KJAER");
        assertEquals(Caesar.decode("DKKLAJ", 'n', 'R'), "HOOPEN");
        assertEquals(Caesar.decode("TUFSMJOH", 'A', 'Z'), "STERLING");
        assertEquals(Caesar.decode("VJGFKDDWM", 'E', 'c'), "THEDIBBUK");
        assertEquals(Caesar.decode("ZQJCAKJIWOPAN", 'W', 'A'), "DUNGEONMASTER");
        assertEquals(Caesar.decode("XHZRGFLGJSOFRNS", 'G', 'B'), "SCUMBAGBENJAMIN");
        assertEquals(Caesar.decode("HEROIHEHHC", 'J', 'F'), "DANKEDADDY");
    }
}