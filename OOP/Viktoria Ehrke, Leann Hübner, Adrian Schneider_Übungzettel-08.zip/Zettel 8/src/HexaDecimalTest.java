import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class HexaDecimalTest {

    @Test
    void toIntValue() {
        HexaDecimal testOne = new HexaDecimal("154B3");
        HexaDecimal testTwo = new HexaDecimal("FC7AFD");
        assertEquals(testOne.toIntValue(), 87219);
        assertEquals(testTwo.toIntValue(), 16546557);
    }

    @Test
    void fromIntValue() {
        HexaDecimal testOne = new HexaDecimal("0"); //erstelle zwei Objekte mit beliebiger Eingabe
        HexaDecimal testTwo = new HexaDecimal("0");
        testOne.fromIntValue(2810); //das setzt den value jeweils neu
        testTwo.fromIntValue(1312);
        assertEquals(testOne.value, "AFA"); //test für den neuen value
        assertEquals(testTwo.value, "520");
        assertNotEquals("0", testOne.value); //test das der alte value nicht mehr existiert
        assertNotEquals("0", testTwo.value);
    }
}