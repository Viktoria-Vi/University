public class HexaDecimal implements Number {
    public String value;

    public HexaDecimal(String value) {
        this.value = value.toUpperCase();
    }

    @Override
    public int toIntValue() {
        return Integer.valueOf(value, 16); //das wandelt von selbst aus dem Hexadezimalsystem um
    }

    @Override
    public void fromIntValue(int value) {
        this.value = Integer.toHexString(value).toUpperCase(); //das erstellt einen String im Hexadezimalsystem
    }
}
