import org.junit.jupiter.api.Test;

import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.*;

class CardTest {


    Card card1 = new Card("Viktoria", Card.EFFECT_MONSTER, 2021);
    Card card2 = new Card("Felix", Card.NORMAL_MONSTER, 2021);
    Card card3 = new Card("Anna", Card.NORMAL_MONSTER, 2021);
    Card card4 = new Card("Mankel", Card.NORMAL_MONSTER, 2021);
    Card card5 = new Card("Mimi", Card.EFFECT_MONSTER, 2021);
    Card card6 = new Card("Leann", Card.EFFECT_MONSTER, 2021);
    Card card7 = new Card("Anna spawnt Akito", Card.SPELL_CARD, 2021);
    Card card8 = new Card("Zettelabgabe verschoben", Card.SPELL_CARD, 2020);
    Card card9 = new Card("Tut fällt aus", Card.TRAP_CARD, 2021);
    Card card10 = new Card("Chinesische Ringe", Card.TRAP_CARD, 2020);
    Card card11 = new Card("Tut fällt aus", Card.TRAP_CARD, 2020);//warum auch immer verlangt die Aufgabe so ein bspl
    Card card12 = new Card("Tut fällt aus", Card.TRAP_CARD, 2021); //genaues Duplikaat von card9


    @Test
    void compareTo() {
        Card[] testDeck = new Card[]{card1, card2, card3, card4, card5, card6, card7, card8, card9, card10, card11, card12};//Rohes-array von den Karten
        Arrays.sort(testDeck); //sortiert Array
        Card[] sortedDeck = new Card[]{card8, card10, card11, card3, card2, card4, card6, card5, card1, card7, card9, card12};//richtig sortiertes Deck
        Card[] falseSortedDeck = new Card[]{card8, card10, card11, card3, card2, card4, card6, card5, card1, card7, card12, card9};//Falsch sortiertes Deck(vertauschte letzte stellen)
        assertArrayEquals(testDeck, sortedDeck); //zeigt das die Sortierung klappt, und das Duplikate nach auftreten im Ursprungsarray gerreiht werden
        assertFalse(Arrays.equals(testDeck, falseSortedDeck));//false-Test um das hierrüber nochmal zu unterstützen;
    }
}