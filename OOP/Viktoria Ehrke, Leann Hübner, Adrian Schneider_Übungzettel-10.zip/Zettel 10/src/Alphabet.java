public class Alphabet {
    private final Character[] Symbols;

    public Alphabet(Character[] Symbols) {
        this.Symbols = Symbols;
    }

    public Character[] getSymbols() {
        return Symbols;
    }

    /**
     * Überprüft, ob das übergebene Symbol im Alphabet enthalten ist
     *
     * @return gibt true zurück, wenn das Symbol enthalten ist, false, wenn nicht
     */
    public boolean doesContain(Character Symbol) {
        for (Character item : Symbols) {
            if (item.equals(Symbol)) {
                return true;
            }
        }
        return false;
    }
}
