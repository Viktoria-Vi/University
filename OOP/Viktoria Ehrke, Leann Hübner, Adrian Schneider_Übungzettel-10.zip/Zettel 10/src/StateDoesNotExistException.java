public class StateDoesNotExistException extends Exception {


    public StateDoesNotExistException(String stateID) {
        super("State " + stateID + " does not exist");
    }
}
