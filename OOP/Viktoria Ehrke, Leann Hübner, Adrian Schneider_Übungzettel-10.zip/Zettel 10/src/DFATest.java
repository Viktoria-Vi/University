import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class DFATest {

    @Test
    void DFATestCase() throws Exception {
        //Erstellen von hilfreichen Objekten
        State off = new State("01", true);
        State on = new State("02", true);
        State standBy = new State("03", true);
        State doBeep = new State("04", true);
        Alphabet alphabet = new Alphabet(new Character[]{'a', 'b', 'c', 'd', 'e', 'g', 'h', 'i'});
        DFA test = new DFA(alphabet);
        //Test der Methode addState()
        test.addState(off, true);
        test.addState(on, false);
        test.addState(standBy, false);
        test.addState(doBeep, false);
        assertThrows(StateAlreadyExistsException.class, () -> {
            test.addState(new State("04", false), false);
            ;
        });
        //Test der Methode findState
        assertEquals(test.findState("01"), off);
        assertNull(test.findState("05"));
        //Test der Methode makeTransition
        test.makeTransition("01", "02", alphabet.getSymbols()[0]);
        test.makeTransition("02", "01", 'b');
        test.makeTransition("02", "03", 'c');
        test.makeTransition("03", "01", 'd');
        test.makeTransition("02", "04", 'g');
        test.makeTransition("04", "02", 'h');
        test.makeTransition("03", "02", 'i');
        assertThrows(TransitionAlreadyExistsException.class, () -> {
            test.makeTransition("02", "03", 'c');
        });
        assertThrows(StateDoesNotExistException.class, () -> {
            test.makeTransition("02", "05", 'e');
        });
        assertThrows(SymbolNotInAlphabetException.class, () -> {
            test.makeTransition("01", "04", 'f');
        });
        //Test eines möglichen Durchlaufs von DFA
        test.reset();
        assertEquals(test.delta('a'), "02");//schaltet den DFA an
        assertTrue(test.isAccepting());
        assertEquals(test.delta('c'), "03");//geht in dem Standby
        assertTrue(test.isAccepting());
        assertEquals(test.delta('i'), "02");//geht aus dem StandBy
        assertTrue(test.isAccepting());
        assertEquals(test.delta('g'), "04");//macht Piep an
        assertTrue(test.isAccepting());
        assertEquals(test.delta('h'), "02");//macht Piep aus
        assertTrue(test.isAccepting());
        assertEquals(test.delta('b'), "01");//macht den DFA aus
        assertTrue(test.isAccepting());
        test.reset();
    }
}