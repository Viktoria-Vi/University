public class Transition {
    private final String START, END; //Kuss
    private final Character Symbol;

    public Transition(String START, String END, Character Symbol) {
        this.START = START;
        this.END = END;
        this.Symbol = Symbol;
    }

    public String getSTART() {
        return START;
    }

    public String getEND() {
        return END;
    }

    public Character getSymbol() {
        return Symbol;
    }
}
