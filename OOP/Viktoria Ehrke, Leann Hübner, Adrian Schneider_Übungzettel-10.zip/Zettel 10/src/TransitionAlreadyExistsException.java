public class TransitionAlreadyExistsException extends Exception{

    public TransitionAlreadyExistsException(Transition transition) {
        super("Transition" + transition + "already exists");
    }

    public TransitionAlreadyExistsException(String Start, Character symbol){
        super("Transition with following Symbol and Start already exists " + symbol + "/" + Start);

    }

}

