public class StateAlreadyExistsException extends Exception{

    public StateAlreadyExistsException(String stateID){
        super("State " + stateID + " already exists");
    }

}



