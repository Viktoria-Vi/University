public class SymbolNotInAlphabetException extends Exception {

    public SymbolNotInAlphabetException(Character symbol) {
        super("Symbol " + symbol + " is not included in alphabet");
    }

}
