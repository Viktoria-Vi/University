public class State {
    private final String ID;
    private final boolean validState;

    public State(String ID, boolean valid) {
        this.ID = ID;
        validState = valid;
    }


    public String getID() {
        return ID;
    }

    public boolean isValidState() {
        return validState;
    }
}
