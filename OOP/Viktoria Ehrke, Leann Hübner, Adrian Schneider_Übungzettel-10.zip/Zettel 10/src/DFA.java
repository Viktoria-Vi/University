public class DFA extends GenericAutomaton {
    private String current;

    /**
     * Intitalisiert alle Felder der Oberklasse Genericautomaton, man kann hier current nicht Initialisieren, da
     * uns noch kein State vorliegt welcher das sein könnte.
     *
     * @param alphabet ist ein Array an Symbolen
     */
    public DFA(Alphabet alphabet) {
        super(alphabet);
    }

    /**
     * Setzt den aktuellen State auf den start State aus GenericAutomaton
     */
    @Override
    void reset() {
        current = start;
    }

    /**
     * Schaut ob der aktuelle State ein akzeptierter ist
     *
     * @return ruft das Feld Validstate aus State auf
     */
    @Override
    boolean isAccepting() {
        for (State state : states) {
            if (current.equals(state.getID())) {
                return state.isValidState();
            }
        }
        return false;
    }

    /**
     * Die Methode überprüft, ob es schon eine Transition mit derselben start ID(q1) und Symbol gibt, und ruft dann die methode add Transition auf.
     *
     * @param q1     start ID
     * @param q2     ziel ID
     * @param symbol Zeichen der Transition
     * @throws Exception wirft die TransitionAlreadyExistsException falls q1 und symbol schonmal in einer Transition genau so existieren
     */
    public void makeTransition(String q1, String q2, Character symbol) throws Exception {
        for (Transition transition : transitions) {
            if (q1.equals(transition.getSTART()) && symbol.equals(transition.getSymbol())) {
                throw new TransitionAlreadyExistsException(q1, symbol);
            }
        }
        addTransition(new Transition(q1, q2, symbol));
    }

    /**
     * Setzt einen neuen Zustand im Automaten mithilfe des current Zustandes und dem übergebenen Symbol
     *
     * @param symbol Zeichen der auszuführenden Transition
     * @return gibt den aktuellen Zustand zurück(ohne Grund lol)
     * @throws SymbolNotInAlphabetException war nicht direkt gefordert, is aber sehr sinnvoll
     */
    public String delta(Character symbol) throws SymbolNotInAlphabetException {
        if (!alphabet.doesContain(symbol)) {
            throw new SymbolNotInAlphabetException(symbol);
        }
        for (Transition transition : transitions) {
            if (transition.getSTART().equals(current) && transition.getSymbol().equals(symbol)) {
                current = transition.getEND();
            }
        }
        return current;
    }
}
