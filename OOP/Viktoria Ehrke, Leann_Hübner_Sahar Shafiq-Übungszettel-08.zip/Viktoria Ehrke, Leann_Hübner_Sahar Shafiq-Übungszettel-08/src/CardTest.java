import org.junit.jupiter.api.Test;

import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.*;

class CardTest {

    Card[] testDeck = new Card[]{ //erstellt erst neues Card-Array
            new Card("Viktoria", Card.EFFECT_MONSTER, 2021),
            new Card("Felix", Card.NORMAL_MONSTER, 2021),
            new Card("Anna", Card.NORMAL_MONSTER, 2021),
            new Card("Mankel", Card.NORMAL_MONSTER, 2021),
            new Card("Akito", Card.EFFECT_MONSTER, 2021),
            new Card("Leann", Card.EFFECT_MONSTER, 2021),
            new Card("Anna spawnt Akito", Card.SPELL_CARD, 2021),
            new Card("Zettelabgabe verschoben", Card.SPELL_CARD, 2020),
            new Card("Tut fällt aus", Card.TRAP_CARD, 2021),
            new Card("Chinesische Ringe", Card.TRAP_CARD, 2020)
    };

    @Test
    void compareTo() {
        Arrays.sort(testDeck); //sortiert Array
        assertEquals("[Spellcard: Zettelabgabe verschoben, Trapcard: Chinesische Ringe, NORMAL_MONSTER: Anna," +
                        " NORMAL_MONSTER: Felix, NORMAL_MONSTER: Mankel, EFFECT_MONSTER: Akito, EFFECT_MONSTER: Leann," +
                        " EFFECT_MONSTER: Viktoria, Spellcard: Anna spawnt Akito, Trapcard: Tut fällt aus]",
                Arrays.toString(testDeck)); //vergleicht die sortierte Ausgabe als String mit dem erwarteten String
    }
}