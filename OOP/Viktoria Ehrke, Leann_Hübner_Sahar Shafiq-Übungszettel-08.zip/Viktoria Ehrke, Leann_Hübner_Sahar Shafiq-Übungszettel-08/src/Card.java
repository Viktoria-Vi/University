import java.util.Arrays;

public class Card implements Comparable {

    private final String name;
    private final int type;
    public static final int EFFECT_MONSTER = 2; //Durch das erstellen einzelner Felder kann man nacher mit Card.usw darauf zugreifen (s. CardTest)
    public static final int NORMAL_MONSTER = 1;
    public static final int SPELL_CARD = 3;
    public static final int TRAP_CARD = 4;
    private final int release;

    public Card(String name, int type, int release) {
        this.name = name;
        this.release = release;
        if (type == EFFECT_MONSTER) {
            this.type = EFFECT_MONSTER;
        } else if (type == NORMAL_MONSTER) {
            this.type = NORMAL_MONSTER;
        } else if (type == SPELL_CARD) {
            this.type = SPELL_CARD;
        } else if (type == TRAP_CARD) {
            this.type = TRAP_CARD;
        } else {
            this.type = TRAP_CARD; //unnessecary Statement lol
        }
    }

    public String getName() {
        return name;
    }

    public int getRelease() {
        return release;
    }

    public int getType() {
        return type;
    }

    @Override
    public String toString() { //Schreibt vor wie die toString methode funktioniert
        if (type == 1) {
            return "NORMAL_MONSTER: " + name;
        }
        if (type == 2) {
            return "EFFECT_MONSTER: " + name;
        }
        if (type == 3) {
            return "SPELL_CARD: " + name;
        } else {
            return "TRAP_CARD: " + name;
        }
    }

    @Override
    public int compareTo(Object o) {
        Card other = (Card) o; //Object wir in ein Card-Object umgewandelt(ge-castet)
        int result = Integer.compare(this.getRelease(), other.getRelease());
        if (result == 0) {
            result = Integer.compare(this.getType(), other.getType());
        }
        if (result == 0) {
            result = this.getName().compareTo(other.getName());
        }
        return result;
    }

    public static void main(String[] args) { //muss ne Klasse ne Main haben?

    }
}




