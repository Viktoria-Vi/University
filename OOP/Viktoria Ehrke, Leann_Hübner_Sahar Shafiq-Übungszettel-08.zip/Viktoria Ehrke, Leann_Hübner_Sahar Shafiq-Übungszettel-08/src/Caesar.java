public class Caesar {
    static String decode(String coded, char a, char b) {
        String alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"; //Alphabet für die Entschlüsselung
        int charOne = 0; //Zwischenspeicher für die Stelle von a in Alphabet
        int charTwo = 0; //Zwischenspeicher für die Stelle von b in Alphabet
        for (int i = 0; i < alphabet.length(); i++) {
            if (alphabet.charAt(i) == a || alphabet.toLowerCase().charAt(i) == a) { //Suchen nach a
                charOne = i;
            }
            if (alphabet.charAt(i) == b || alphabet.toLowerCase().charAt(i) == b) { //Suchen nach b
                charTwo = i;
            }
        }
        int distance = charTwo - charOne; //Berechnung der Entfernung der beiden Buchstaben
        String decoded = ""; //Leerer String um das decodierte Wort aufzubauen
        for (int i = 0; i < coded.length(); i++) {
            for (int j = 0; j < alphabet.length(); j++) {
                if (alphabet.charAt(j) == coded.charAt(i)) { //Berechnung der Entschlüsselung
                    if (j + distance > 25) {
                        decoded += alphabet.charAt(j + distance - 25); //Falls der entschlüsselte Index > 25 ist
                    } else if (j + distance < 0) {
                        decoded += alphabet.charAt(j + distance + 25); //Falls der entschlüsselte Index < 25 ist
                    } else {
                        decoded += alphabet.charAt(j + distance);
                    }
                }
            }
        }
        return decoded;
    }
    public static void main(String[] args) {
        decode("HGXBO", 'W', 'Z');
        decode("DKKLAJ", 'n', 'R');
        decode("TUFSMJOH", 'A', 'Z');
        decode("VJGFKDDWM", 'E', 'c');
        decode("ZQJCAKJIWOPAN", 'W', 'A');
        decode("XHZRGFLGJSOFRNS", 'G', 'B');
    }

}
