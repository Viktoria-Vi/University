package Tag2;

public enum CollisionDirection {
    NONE,
    HORIZONTAL,
    VERTICAL,
    BOTH

}
