package Tag2;

import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        try {
            Integer.parseInt(args[0]);
            Integer.parseInt(args[1]);
        } catch (NumberFormatException e){
            e.printStackTrace();
        }
        if (args.length > 2){
            System.out.println("Wrong input. Accepted input: int int");
        }
        

        }
    }

