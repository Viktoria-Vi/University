package ga.framework.operators;

public class SurvivalException extends Exception {
    public SurvivalException(String msg) {
        super(msg);
    }
}
