package de.umr.ds.task2;


public class EchoServer {

	public static void main(String[] args) {

		// TODO Task 2b)

	}
}
