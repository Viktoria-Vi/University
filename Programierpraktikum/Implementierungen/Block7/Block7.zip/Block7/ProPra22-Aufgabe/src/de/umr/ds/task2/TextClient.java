package de.umr.ds.task2;


public class TextClient {

	public static void main(String[] args) {

		// TODO Task 2a)

	}
}