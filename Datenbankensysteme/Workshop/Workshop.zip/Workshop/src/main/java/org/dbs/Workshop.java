package org.dbs;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Workshop {
    private final Connection conn;
    private final CustomersDAO customersDAO;

    public Workshop(Connection connection) {
        this.conn = connection;
        this.customersDAO = new CustomersDAO(connection);
    }

    public void listCategories() throws SQLException {
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT * FROM categories LIMIT 3");
        // Extract data from result set
        while (rs.next()) {
            // Retrieve by column name
            System.out.print("ID: " + rs.getInt("category_id"));
            System.out.print(", name: " + rs.getString("category_name") + "\n");
        }
    }

    public void listDetails(int productID) throws SQLException {
        String productName = "";
        String supplierCompanyName = "";
        String categoryName = "";
        String categoryDescription = "";
        int totalOrders = 0;
        float avgPrice = 0;
        List<String> employeeNames = new ArrayList<>();
        List<String> shipperCompanyNames = new ArrayList<>();
        HashMap<String,Integer> top5Customers = new HashMap<>();

        // Aufgabe 2

        System.out.println("Details for product with ID " + productID);
        System.out.print("Product name: " + productName + "\n" +
                "Supplier: " + supplierCompanyName + "\n" +
                "Category name: " + categoryName + "\n" +
                "Category desc.: " + categoryDescription + "\n" +
                "Total orders: " + totalOrders + "\n" +
                "Average price: " + avgPrice + "\n" +
                "Employees involved: " + employeeNames.toString() + "\n" +
                "Shippers involved: " + shipperCompanyNames.toString() + "\n" +
                "Top 5 customers: " + top5Customers.toString());
    }

    public void insertEmployees(String fileName) throws SQLException {
        // Aufgabe 3
    }

    public void listCustomers() throws SQLException {
        List<Customer> customers = this.customersDAO.findAll();
        for (Customer customer : customers) {
            System.out.println(customer.toString());
        }
    }

    public void updateCustomers(int companyChars, int contactChars) throws SQLException {
        // Aufgabe 5
    }

    public void deleteCustomer(String ID, boolean force) throws SQLException {
        this.customersDAO.deleteCustomer(ID, force);
    }

    public void addPromo(int productID) throws SQLException {
        // Aufgabe 7
    }

    public void insertUSState(String stateName) throws SQLException {
        // Aufgabe 8
    }
}
